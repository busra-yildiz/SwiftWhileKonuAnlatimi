import UIKit

//1,2,3 yazdıran while döngüsü yazalım

var sayac = 1

while sayac < 4 {
    print ("Döngü 4 :\(sayac)")
    sayac+=1
}
